﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallTile : StageObjectBase
{

	// Update is called once per frame
	void Update()
    {
        
    }
}
