﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageTrap : TrapBase
{
    protected override void OnActivate(StageObjectBase character)
    {
        
    }

    // Start is called before the first frame update
    protected override void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
